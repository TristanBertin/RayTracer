
class Ray
{
public:
	Ray(const Vector& C, const Vector& u) : C(C), u(u) {};
	Vector C;
	Vector u;
};

